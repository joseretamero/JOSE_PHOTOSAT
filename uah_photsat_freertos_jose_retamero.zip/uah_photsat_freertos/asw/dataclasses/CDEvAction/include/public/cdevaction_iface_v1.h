/*
 * cdeventlist_iface_v1.h
 *
 *  Created on: Dec 20, 2023
 *      Author: user
 */

#ifndef CDEVACTION_IFACE_V1_H_
#define CDEVACTION_IFACE_V1_H_

#include <public/cdevaction.h>

#endif /* CDEVACTION_IFACE_V1_H_ */
