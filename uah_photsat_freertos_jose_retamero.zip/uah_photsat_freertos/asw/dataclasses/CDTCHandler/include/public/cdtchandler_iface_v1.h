/*
 * cdtcdescriptor_iface_v1.h
 *
 *  Created on: Dec 20, 2016
 *      Author: user
 */

#ifndef CDTCHANDLER_IFACE_V1_H_
#define CDTCHANDLER_IFACE_V1_H_

#include "cdtchandler.h"

#endif /* CDTCHANDLER_IFACE_V1_H_ */
